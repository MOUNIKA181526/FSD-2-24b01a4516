function Student(props) {
  return (
    <div>
      <h2>Name: {props.name}</h2>
      <p>Branch: {props.branch}</p>
    </div>
  );
}

function App() {
  return (
    <div>
      <Student name="Mounika" branch="AI & DS" />
    </div>
  );
}

export default App;
