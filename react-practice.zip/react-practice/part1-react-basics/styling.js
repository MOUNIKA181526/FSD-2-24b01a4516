function App() {
  return (
    <div>
      <h1 style={{ color: "blue", textAlign: "center" }}>
        Welcome to React
      </h1>
    </div>
  );
}

export default App;
