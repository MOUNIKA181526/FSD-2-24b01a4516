import React, { Component } from "react";

class Student extends Component {
  render() {
    return (
      <div>
        <h2>Name: Mounika</h2>
        <p>Branch: AI & DS</p>
      </div>
    );
  }
}

class App extends Component {
  render() {
    return (
      <div>
        <h1>Student Information</h1>

        {/* Nested Component */}
        <Student />
      </div>
    );
  }
}

export default App;
