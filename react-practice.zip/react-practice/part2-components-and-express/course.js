import React, { Component } from "react";

class Student extends Component {
  render() {
    return (
      <div>
        <h2>Name: Mounika</h2>
        <p>Branch: AI & DS</p>
      </div>
    );
  }
}

function App() {
  return (
    <div>
      <h1>College Portal</h1>

      <Student />
    </div>
  );
}

export default App;
