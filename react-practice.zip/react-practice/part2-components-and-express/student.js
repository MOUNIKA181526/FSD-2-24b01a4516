import React, { Component } from "react";

function Student() {
  return (
    <div>
      <h2>Name: Mounika</h2>
      <p>Branch: AI & DS</p>
    </div>
  );
}

class App extends Component {
  render() {
    return (
      <div>
        <h1>College Portal</h1>

        <Student />
      </div>
    );
  }
}

export default App;
