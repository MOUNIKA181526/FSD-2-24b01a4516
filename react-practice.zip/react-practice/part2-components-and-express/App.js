import express from "express";

const app = express();

app.get("/", (req, res) => {
    res.send(`
        <html>
        <head>
            <title>My Web Page</title>
        </head>
        <body>
            <h1>Welcome to Express</h1>
            <p>This HTML is rendered using Express.</p>
        </body>
        </html>
    `);
});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});
