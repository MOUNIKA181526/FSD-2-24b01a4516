function Student() {
  return (
    <div>
      <h2>Name: Mounika</h2>
      <p>Branch: AI & DS</p>
    </div>
  );
}

function App() {
  return (
    <div>
      <h1>Student Information</h1>

      {/* Nested Component */}
      <Student />
    </div>
  );
}

export default App;
